import React ,{useState,useEffect} from 'react'
import {View,Text,TouchableOpacity ,StyleSheet} from 'react-native'
import LinearGradient from 'react-native-linear-gradient'

export default  function Main(){
const [sec,setSec]=useState(25);
const [interval,setInter]=useState(0);
let cont=0
state={
    start:false,
    time:{
        sec:'',
        interval:''
    },
    status: 'Start'
}


function ContTime(){

    if (sec>0 && interval==0){
    setInterval(setSec(...sec-1),
        
        1000)
    setInter(0)
    }
    else{
        setInterval(
          setInter(interval+1)          
            ,
          1000
        )
        setSec(25)
    }
    
    }

useEffect( ()=>{
 ContTime()
},[state.status])

function Button(){
  if (cont==1){

  }
  
   else if(cont==0){
    
  }
}

return(
<LinearGradient  colors={['#7159c','#9b49c1']} start={0,0} end={1,1} style={{flex:1}}>
<View  style={styles.consteiner}>
<View>
<Text style={{ color:'#fff',marginTop:20,fontSize:40,fontWeight:'bold'}}>{state.time.interval}</Text>
<Text style={styles.text1}>{state.time.sec}</Text>
</View>
<TouchableOpacity style={styles.button} onpress={()=>{state.start=true}}>
<Text style={styles.text2}>{state.status}</Text>
</TouchableOpacity>

</View>
</LinearGradient>
);
}

const styles =StyleSheet.create({
consteiner:{
 flex:1,
 alignItems:'center',
 flexDirection:'column'
 

},
text1:{
    color:'#fff',
    marginTop:20,
    fontSize:40,
    fontWeight:'bold'
},
text2:{
    color:'#fff',
    marginTop:20,
    fontSize:20,
    alignItems:'center',
    alignSelf:'center',
    fontWeight:'bold'
},
button:{
    backgroundColor:'#453775',
    marginRight:40,
    borderRadius:8,
    marginLeft:40,
    alignItems:'center',
    borderWidth:0.5,
    justifyContent:'center',
    borderColor:'#737380',
    height:30,
    width:70,
}

})