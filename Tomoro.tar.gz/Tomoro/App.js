import React from 'react'
import Main from './src/main/index';


export default function App(){
return(
<Main/>
)
}